# 02 — Sinteza kombinacionih mreža

Original: `../02 Sinteza kombinacionih mreza.pdf`, 27 PDF strana i 54 izvorna slajda; Digitalna elektronika 1, 2021/22, Katedra za elektroniku, prof. dr Lazar Saranovac.

Aktuelni redizajn od 2026-10-03 ima **56 projektovanih slajdova i 56 A4 strana sa beleškama**. Korisnik je izričito odobrio podelu s002 i s009; nastavci su s002b i s009b. Ostali ID-jevi ostaju isti. Status: `ceka_odobrenje`; sve provere prolaze, nema otvorenih stručnih pitanja. Vidi [izveštaj](provera/redizajn/izvestaj.md), [odluke](provera/redizajn/odluke.md) i [odobrenje podele](provera/redizajn/odobrenje_podela.json).

[Prezentacija](build/02_sinteza_kombinacionih_mreza.pdf), [beleške](build/02_sinteza_kombinacionih_mreza_beleske.pdf), [uporedni pregled](build/redizajn/pregled/index.html). Izlazi se generišu i ne verzionišu.

```bash
make -C predavanja LECTURE=02_sinteza_kombinacionih_mreza all
make -C predavanja LECTURE=02_sinteza_kombinacionih_mreza notes
make -C predavanja LECTURE=02_sinteza_kombinacionih_mreza review
make -C predavanja LECTURE=02_sinteza_kombinacionih_mreza check
```

Istorijska `provera/mapa.json` čuva 54 izvorne lokacije i ID-ja; prethodna `provera/pregled.json` prati rekonstrukciju. Novi inventar, pokrivenost, odluke i aktuelne potvrde vode se u `provera/redizajn/`. Istorijska rekonstrukcija je završena 54/54; njene potvrde ne zamenjuju pregled redizajna.
